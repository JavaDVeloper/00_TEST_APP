package com.barpiotr.MyFirstMavenApp.menu;

public interface IExecutable {
	public void execute();
}
